import 'dart:convert';

import 'package:bytebankbd/http/web_client.dart';
import 'package:bytebankbd/models/transaction.dart';
import 'package:http/http.dart';

class TransactionWebClient {
  Future<List<Transaction>> findAll() async {
    final Response response = await client.get(baseUrl).timeout(
          Duration(seconds: 5),
        );
    final List<dynamic> decodedJson = jsonDecode(response.body);
    final List<Transaction> transactions =
        decodedJson.map((dynamic json) => Transaction.fromJson(json)).toList();
    //List<Transaction> transactions = _toTransactions(response);
    return transactions;
  }

  Future<Transaction> save(Transaction transaction, String password) async {
    final String transactionJson = jsonEncode(transaction.toJson());

    final Response response = await client.post(
      baseUrl,
      headers: {
        'Content-Type': 'application/json',
        'password': password,
      },
      body: transactionJson,
    );
print('response.statusCode ==> ${response.statusCode}');
    if(response.statusCode == 400){
      throw Exception('there was an error submitting transaction');
    }

    if(response.statusCode == 401){
      throw Exception('authentication failed');
    }
    return Transaction.fromJson(jsonDecode(response.body));
  }

 /* List<Transaction> _toTransactions(Response response) {
    final List<dynamic> decodedJson = jsonDecode(response.body);
    final List<Transaction> transactions =
        decodedJson.map((dynamic json) => Transaction.fromJson(json)).toList();*/

    // final List<Transaction> transactions = List();
    // for (Map<String, dynamic> transactionJson in decodedJson) {
    //   transactions.add(Transaction.fromJson(transactionJson));
    // }
   /* return transactions;
  }*/
}
