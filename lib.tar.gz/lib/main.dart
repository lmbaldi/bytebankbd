import 'package:bytebankbd/components/transaction_auth_dialog.dart';
import 'package:bytebankbd/screens/dashboard.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(ByteBankBd());
  //findAll().then((transactions) => print('new transaction ==> ${transactions}'));
}

class ByteBankBd extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: Colors.green[900],
        accentColor: Colors.blue[700],
        buttonTheme: ButtonThemeData(
          buttonColor: Colors.blueAccent[700],
          textTheme: ButtonTextTheme.primary,
        ),
      ),
      home: Dashboard(),
    );
  }
}



